package com.codefolio.registory.Server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistoryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
