package com.codefolio.registory.Server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistoryServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistoryServerApplication.class, args);
	}

}
